// Game state variables
const board = Array(9).fill(null);
let currentPlayer = "X";
let gameActive = true;
let gameMode = "pvp"; // "pvp" for Player vs Player, "pvc" for Player vs Computer
let difficulty = "easy";

// Cached DOM elements
const cells = document.querySelectorAll(".cell");
const statusDisplay = document.getElementById("status");
const resetButton = document.getElementById("reset");
const modeSelect = document.getElementById("mode");
const difficultySelect = document.getElementById("difficulty");
const confettiContainer = document.getElementById("confetti-container");
const clapSound = document.getElementById("clapSound");
const themeSound = document.getElementById("themeSound");
const clapImage = document.getElementById("clapImage");

// Set the clapping sound to maximum volume.
clapSound.volume = 1;

// Start playing the theme song after the first user interaction.
document.body.addEventListener("click", () => {
  if (themeSound.paused) {
    themeSound.volume = 0.3;
    themeSound.play();
  }
}, { once: true });

// Winning combinations (rows, columns, diagonals)
const winningCombos = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6]
];

// Event listeners for configuration
modeSelect.addEventListener("change", () => {
  gameMode = modeSelect.value;
  difficultySelect.disabled = (gameMode !== "pvc");
  resetGame();
});

difficultySelect.addEventListener("change", () => {
  difficulty = difficultySelect.value;
  resetGame();
});

// Handle human move on a cell
function handleCellClick(e) {
  const index = e.target.getAttribute("data-index");
  if (board[index] || !gameActive) return;
  
  // Player marks the cell
  board[index] = currentPlayer;
  e.target.textContent = currentPlayer;
  checkResult();
}

// Check for win or tie after each move
function checkResult() {
  let roundWon = false;
  for (const combo of winningCombos) {
    const [a, b, c] = combo;
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      roundWon = true;
      break;
    }
  }

  if (roundWon) {
    statusDisplay.textContent = `Player ${currentPlayer} wins!`;
    gameActive = false;
    // Show clapping hands image and play clapping sound.
    clapImage.style.display = "block";
    clapSound.play();
    triggerConfetti();
    // Hide clapping image after 2.5 seconds and reset game.
    setTimeout(() => {
      clapImage.style.display = "none";
      resetGame();
    }, 3000);
    return;
  }

  if (!board.includes(null)) {
    statusDisplay.textContent = "It's a tie!";
    gameActive = false;
    setTimeout(resetGame, 3000);
    return;
  }

  // Switch turns
  currentPlayer = currentPlayer === "X" ? "O" : "X";
  statusDisplay.textContent = `Player ${currentPlayer}'s turn`;

  // If playing against computer and it's computer's turn, trigger computer move.
  if (gameActive && gameMode === "pvc" && currentPlayer === "O") {
    setTimeout(computerTurn, 500);
  }
}

// Reset game state and clear board
function resetGame() {
  board.fill(null);
  gameActive = true;
  currentPlayer = "X";
  statusDisplay.textContent = `Player ${currentPlayer}'s turn`;
  cells.forEach(cell => (cell.textContent = ""));
  clearConfetti();
}

// Confetti effect: Create 150 falling confetti pieces (using flower emojis)
function triggerConfetti() {
  for (let i = 0; i < 150; i++) {
    const confetti = document.createElement("div");
    confetti.classList.add("confetti");
    const emojis = ["🌸", "🌼", "💮", "🌺", "🌷"];
    confetti.textContent = emojis[Math.floor(Math.random() * emojis.length)];
    confetti.style.left = Math.random() * 100 + "vw";
    confetti.style.animationDuration = (3 + Math.random() * 2) + "s";
    confetti.style.animationDelay = Math.random() * 0.5 + "s";
    confettiContainer.appendChild(confetti);
    setTimeout(() => confetti.remove(), 6000);
  }
}

function clearConfetti() {
  confettiContainer.innerHTML = "";
}

// Computer's turn: decide and make a move based on the selected difficulty.
function computerTurn() {
  if (!gameActive) return;
  const move = getBestMove(board, difficulty);
  if (move !== null) {
    board[move] = currentPlayer;
    cells[move].textContent = currentPlayer;
    checkResult();
  }
}

// Get best move for computer based on difficulty level.
function getBestMove(currentBoard, level) {
  let availableMoves = [];
  currentBoard.forEach((cell, i) => {
    if (!cell) availableMoves.push(i);
  });
  
  if (availableMoves.length === 0) return null;
  
  if (level === "easy") {
    // Random move.
    return availableMoves[Math.floor(Math.random() * availableMoves.length)];
  } else if (level === "medium") {
    // Check for winning move or block opponent, else random.
    for (let move of availableMoves) {
      let boardCopy = [...currentBoard];
      boardCopy[move] = "O";
      if (checkWinner(boardCopy, "O")) return move;
    }
    for (let move of availableMoves) {
      let boardCopy = [...currentBoard];
      boardCopy[move] = "X";
      if (checkWinner(boardCopy, "X")) return move;
    }
    return availableMoves[Math.floor(Math.random() * availableMoves.length)];
  } else if (level === "hard") {
    // Use minimax algorithm.
    return minimaxMove(currentBoard, "O").index;
  }
}

// Helper: Check if a board has a winner for a given player.
function checkWinner(bd, player) {
  for (const combo of winningCombos) {
    const [a, b, c] = combo;
    if (bd[a] === player && bd[b] === player && bd[c] === player) {
      return true;
    }
  }
  return false;
}

// Minimax algorithm for hard difficulty level.
function minimaxMove(newBoard, player) {
  let availSpots = [];
  newBoard.forEach((cell, i) => {
    if (!cell) availSpots.push(i);
  });
  
  if (checkWinner(newBoard, "X")) return { score: -10 };
  if (checkWinner(newBoard, "O")) return { score: 10 };
  if (availSpots.length === 0) return { score: 0 };

  let moves = [];
  for (let i = 0; i < availSpots.length; i++) {
    let move = {};
    move.index = availSpots[i];
    newBoard[availSpots[i]] = player;
    
    if (player === "O") {
      let result = minimaxMove(newBoard, "X");
      move.score = result.score;
    } else {
      let result = minimaxMove(newBoard, "O");
      move.score = result.score;
    }
    
    newBoard[availSpots[i]] = null;
    moves.push(move);
  }
  
  let bestMove;
  if (player === "O") {
    let bestScore = -Infinity;
    moves.forEach(m => {
      if (m.score > bestScore) {
        bestScore = m.score;
        bestMove = m;
      }
    });
  } else {
    let bestScore = Infinity;
    moves.forEach(m => {
      if (m.score < bestScore) {
        bestScore = m.score;
        bestMove = m;
      }
    });
  }
  return bestMove;
}

// Attach event listeners for human moves and reset button.
cells.forEach(cell => cell.addEventListener("click", handleCellClick));
resetButton.addEventListener("click", resetGame);





